from Jackson.Game import Jackson

def run(debug=False):
    Jackson().run(debug)